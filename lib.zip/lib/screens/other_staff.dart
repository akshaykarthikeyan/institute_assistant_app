import 'package:flutter/material.dart';

class OtherStaff extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(),
      ),
      backgroundColor: Colors.white,
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.red.shade500,
        title: Text(
          'Other Staffs',
          style: TextStyle(color: Colors.white),
        ),
      ),
    );
  }
}
