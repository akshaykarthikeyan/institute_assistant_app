import 'package:flutter/material.dart';
import 'package:institute_assistant_app/screens/students_list%20_attendance.dart';

class StudentPage extends StatelessWidget {
  List cd = ['1 A', '1 B', '1 C', '1 D'];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.red.shade500,
        title: Text(
          'Students',
          style: TextStyle(color: Colors.white),
        ),
      ),
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Center(
              child: Container(
                color: Colors.white,
                child: Text(
                  'Classes & Divisions',
                  style: TextStyle(fontSize: 25.0, color: Colors.black),
                ),
              ),
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Container(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            primary: Colors.red.shade500),
                        onPressed: () {
                          Navigator.push(context,
                              MaterialPageRoute(builder: (context) => Name()));
                        },
                        child: Container(
                          child: Text(
                            '1 A',
                            style:
                                TextStyle(color: Colors.white, fontSize: 20.0),
                          ),
                        ),
                      ),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            primary: Colors.red.shade500),
                        onPressed: () {},
                        child: Container(
                          child: Text(
                            '1 B',
                            style:
                                TextStyle(color: Colors.white, fontSize: 20.0),
                          ),
                        ),
                      ),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            primary: Colors.red.shade500),
                        onPressed: () {},
                        child: Container(
                          child: Text(
                            '1 C',
                            style:
                                TextStyle(color: Colors.white, fontSize: 20.0),
                          ),
                        ),
                      ),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            primary: Colors.red.shade500),
                        onPressed: () {},
                        child: Container(
                          child: Text(
                            '1 D',
                            style:
                                TextStyle(color: Colors.white, fontSize: 20.0),
                          ),
                        ),
                      ),
                    ],
                  ),
                  width: double.infinity,
                  height: 40.0,
                  color: Colors.white,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
