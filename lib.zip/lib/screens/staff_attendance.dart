import 'package:flutter/material.dart';

class StaffAttendance extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
