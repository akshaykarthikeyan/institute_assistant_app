import 'package:flutter/material.dart';

class StudentName extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Container(
              color: Colors.red.shade500,
              child: ListTile(
                leading: Text(
                  'Names',
                  style: TextStyle(fontSize: 20.0),
                ),
              ),
            ),
          ],
        ),
      ),
      backgroundColor: Colors.black,
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.red.shade500,
        title: Text(
          'Students name and Attendance',
          style: TextStyle(color: Colors.black),
        ),
      ),
    );
  }
}
