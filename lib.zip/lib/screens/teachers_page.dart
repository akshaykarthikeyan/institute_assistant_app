import 'package:flutter/material.dart';

class TeachersPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.red.shade500,
        title: Text(
          'Teachers',
          style: TextStyle(color: Colors.white),
        ),
      ),
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Center(
              child: Container(
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(primary: Colors.red.shade500),
                  onPressed: () {},
                  child: Text(
                    ' Attendance ',
                    style: TextStyle(color: Colors.white, fontSize: 20.0),
                  ),
                ),
              ),
            ),
            Center(
              child: Container(
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(primary: Colors.red.shade500),
                  onPressed: () {},
                  child: Text(
                    ' Time Table ',
                    style: TextStyle(color: Colors.white, fontSize: 20.0),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
