import 'package:flutter/material.dart';

class TeachersTimetable extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
